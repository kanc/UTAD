#ifndef UGINE_GLINCLUDE_H
#define UGINE_GLINCLUDE_H

#include "../lib/glfw.h"

#endif
