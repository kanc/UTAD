#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:mainCRTStartup")

#include "include/u-gine.h"

int main(int argc, char* argv[]) 
{
	Screen::Instance().Open(800, 600, false);
		
	int mousex = NULL;
	int mousey = NULL;
	int radius = 30;
	int lado = 50;
	double angle = 0;	
	
	while ( Screen::Instance().IsOpened() && !Screen::Instance().KeyPressed(GLFW_KEY_ESC) ) {

		double circlex, circley;

		mousex = Screen::Instance().GetMouseX();
		mousey = Screen::Instance().GetMouseY();
				
		circlex = mousex + DegCos(WrapValue(angle,360)) * radius;
		circley = mousey - (DegSin(WrapValue(angle,360)) * radius);

		angle+= Screen::Instance().ElapsedTime() * 30; //para que gire una vez por segundo

		//pintamos		
		Renderer::Instance().Clear();

		Renderer::Instance().SetColor(0,255,0,0);
		Renderer::Instance().DrawRect(400 - lado/2, 300 -lado/2,lado,lado);

		Renderer::Instance().SetColor(0,0,255,0);
		Renderer::Instance().DrawRect(mousex - 5, mousey - 5,10,10);
		
		Renderer::Instance().SetColor(255,0,0,0);
		Renderer::Instance().DrawEllipse(circlex,circley,5,5);

		Screen::Instance().SetTitle(String("Angulo: ") + String::FromFloat(Angle(mousex,mousey,circlex,circley)) + String(" - Distancia: ") +  String::FromFloat(Distance(mousex,mousey,800/2, 600/2 )) );

		Screen::Instance().Refresh();
	}
	
	return 0;
}

